# TODO

- Finish textures
- - Load subtextures (tex3ds)
- - Load subtextures (GL)
- - Copy textures
- Support OpenGL 1.1
- Add support for extensions (shadow, gas, blockmode32, etc).
- Optimize the whole library
- Clean documentation
- Make sure "TODO" does not appear anywhere in the code